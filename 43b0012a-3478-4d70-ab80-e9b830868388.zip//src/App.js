import "./styles.css";
import { useState } from "react";

export default function App() {
  wordList = ["train", "eagle", "spawn", "maybe", "batch", "round", "under"];

  let [gameStatus, setGameStatus] = useState("mid");
  let word = wordList[Math.floor(Math.random() * wordList.length)];

  const calculateWin = () => {
    //  guessMatrix[turn].map((stat)=>{}
  };

  const calcBackgroundColor = (status) => {
    if (status == "y") {
      return "green";
    } else if (status == "in") {
      return "yellow";
    }
    return "red";
  };

  let wordArray = [
    { letter: "T", id: 0 },
    { letter: "R", id: 1 },
    { letter: "A", id: 2 },
    { letter: "I", id: 3 },
    { letter: "N", id: 4 },
  ];

  const [guessMatrix, setGuessMatrix] = useState([
    ["", "", "", "", ""],
    ["", "", "", "", ""],
    ["", "", "", "", ""],
    ["", "", "", "", ""],
    ["", "", "", "", ""],
  ]);

  const [turn, setTurn] = useState(0);

  const [currentGuess, setCurrentGuess] = useState(["", "", "", "", ""]);

  const handleGuess = () => {
    let tempMatrix = guessMatrix;

    const correctArray = currentGuess.map((guess, index) => {
      let inWord = false;
      if (guess == wordArray[index].letter) {
        return "y";
      } else {
        wordArray.map((obj) => {
          if (obj.letter == guess) {
            inWord = true;
          }
        });
        if (inWord) {
          return "in";
        } else {
          return "n";
        }
      }
    });
    tempMatrix[turn] = correctArray;
    setGuessMatrix(tempMatrix);
    setTurn(turn + 1);
  };

  const handleInput = (e) => {
    index = e.target.id;
    const guessUpdate = currentGuess.map((g, i) => {
      if (index == i) {
        return e.target.value.toUpperCase();
      } else {
        return g;
      }
    });
    setCurrentGuess(guessUpdate);
  };
  return (
    <div className="App">
      <div className="boxContainer">
        {guessMatrix.map((array, row) =>
          wordArray.map((letter, key) => (
            <div key={key} className="letterbox">
              <input
                id={key}
                className="letterInput"
                maxLength={1}
                onInput={handleInput}
                disabled={turn == row ? false : true}
                style={{
                  backgroundColor:
                    array[key] != "" ? calcBackgroundColor(array[key]) : "",
                }}
              ></input>
            </div>
          ))
        )}
      </div>

      <button id="guessButton" onClick={handleGuess}>
        Guess
      </button>
      <div id="testSection">
        <p>{turn}</p>

        <p>{currentGuess}</p>
        <p>{guessMatrix}</p>
        <p> game status: {gameStatus} </p>
      </div>
    </div>
  );
}
